from config import *
from config_2 import*
from Bot import*
from tkinter import *

Bot = Cripto_Bot(api_key=api_key, api_secret=api_secret, cripto=CRIPTO, ref=REF, leverage=LEVERAGE, side=SIDE, capital=CAPITAL)



def server():
    app = Flask(__name__)

    @app.route("/")
    def home():

        return render_template('home.html')

    @app.route("/webhook", methods=['POST'])
    def webhook():
        # print(request.data)
        data = json.loads(request.data)
        # print(data['ticker'])
        if data['ticker'].upper() == 'BUY':
            Bot.Buy()
            print('compra ejecutada')
        else:
            if data['ticker'].upper() == 'SELL':
                Bot.Sell()
                print('Venta Ejecutada')
            else:
                print('Error en la Orden')
        return {
            "code": "succes"
        }

    @app.route("/about")
    def about():
        return render_template('about.html')

    @app.route("/Config")
    def config():
        return render_template('config.html')

    @app.route('/pru', methods=['POST'])
    def ini():
        if request.method == 'POST':
            nombre = request.form['nombre']
            print(nombre)

            return 'recibido'

    if __name__ == '__main__':
        app.run(debug=True)

server()




















'''''
ventana = Tk()
ventana.geometry("400x300")
boton1 = Button(ventana, text="BUY", command=Bot.server())
boton1.place(x=20,y=20)

ventana.mainloop()


#Bot.run()

'''
