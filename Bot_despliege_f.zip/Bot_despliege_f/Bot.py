from utils import*
import time
import datetime as dt
import pytz
import json
from flask import Flask, request, render_template


class Cripto_Bot():
    open = False
    def __init__(self, api_key, api_secret, cripto, ref, leverage, side, capital):
        self.client = RequestClient(api_key=api_key, secret_key=api_secret)

        try:
            self.client.change_position_mode(dualSidePosition=True)

        except:
            pass

        #Todos estos datos los recibimos del config_2
        self.cripto = cripto
        self.ref = ref
        self.exchange = self.cripto + self.ref
        self.side = side
        self.single_operation_capital = capital
        self.leverage = leverage

        try:
            self.client.change_initial_leverage(symbol=self.cripto + self.ref, leverage=self.leverage)
        except:

            print('Error En el apalancamiento')

            # Filtros
            result = self.client.get_exchange_information()
            self.minQty, self.stepSize, self.maxQty = Get_Exchange_filters(result, self.exchange)

            self.maxDeciamlQty = Calculate_max_Decimal_Qty(self.stepSize)#pasamos el stepSize para calcular

            self.capital = Get_Capital(self.client.get_account_information(), self.ref)#Obtenemos el capital USD

            self.buysignal = None
            self.sellsignal = None

            self.quantity = None



    def Order(self, side, price):
        Qty = Calculate_Qty(price, self.single_operation_capital * self.leverage, self.minQty, self.maxQty,self.maxDeciamlQty)
        self.quantity = Qty

        if not Qty:
            print('Capital insuficiente')

        if self.side == 'LONG':

            if side == 'BUY':
                self.quantity = Qty
                self.open = True
            else:
                self.open = False
        else:

            if side == 'SELL':

                self.quantity = Qty
                self.open = True
            else:
                self.open = False


        self.client.post_order(symbol=self.exchange, side=side, ordertype='MARKET', quantity=self.quantity,
                               positionSide=self.side)


    def Buy(self):
        price = self.client.get_symbol_price_ticker(symbol=self.cripto + self.ref)[0].price
        result = self.client.get_exchange_information()
        self.minQty, self.stepSize, self.maxQty = Get_Exchange_filters(result, self.exchange)
        self.maxDeciamlQty = Calculate_max_Decimal_Qty(self.stepSize)
        self.capital = Get_Capital(self.client.get_account_information(), self.ref)

        self.side = 'LONG'
        if self.open == False:
            # LONG + BUY = Abre compra
            try:
                self.side = 'LONG'
                self.Order(side="BUY", price=price)
                self.open = True

            except Exception as e:
                print(e)
        else:
            # SHORT + BUY = Cierra venta
            try:
                self.side = 'SHORT'
                self.Order(side="BUY", price=price)
                self.open = False
            except Exception as e:
                print(e)

                # volvemos a abrir la Compra
        if self.open == False:
            try:
                self.side = 'LONG'
                self.Order(side="BUY", price=price)
                self.open = True

            except Exception as e:
                print(e)

    def Sell(self):
        price = self.client.get_symbol_price_ticker(symbol=self.cripto + self.ref)[0].price
        result = self.client.get_exchange_information()
        self.minQty, self.stepSize, self.maxQty = Get_Exchange_filters(result, self.exchange)
        self.maxDeciamlQty = Calculate_max_Decimal_Qty(self.stepSize)
        self.capital = Get_Capital(self.client.get_account_information(), self.ref)

        self.side = 'SHORT'
        if self.open == False:

            try:
                self.Order(side="SELL", price=price)
                self.open = True
            except Exception as e:
                print(e)

        else:
            try:
                # LONG + SELL = Cierre Compra
                self.side = 'LONG'
                self.Order(side="SELL", price=price)
                self.open = False
            except Exception as e:
                print(e)

        if self.open == False:
            self.side = 'SHORT'
            try:
                self.Order(side="SELL", price=price)
                self.open = True

            except Exception as e:
                print(e)


























